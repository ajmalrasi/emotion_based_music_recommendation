op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  conv1 : __torch__.torch.nn.modules.module.___torch_mangle_33.Module
  bn1 : __torch__.torch.nn.modules.module.___torch_mangle_34.Module
  relu : __torch__.torch.nn.modules.module.___torch_mangle_35.Module
  conv2 : __torch__.torch.nn.modules.module.___torch_mangle_36.Module
  bn2 : __torch__.torch.nn.modules.module.___torch_mangle_37.Module
  downsample : __torch__.torch.nn.modules.module.___torch_mangle_40.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_41.Module,
    argument_1: Tensor) -> Tensor:
    _0 = self.downsample
    _1 = self.bn2
    _2 = self.conv2
    _3 = self.relu
    _4 = (self.bn1).forward((self.conv1).forward(argument_1, ), )
    _5 = (_1).forward((_2).forward((_3).forward(_4, ), ), )
    input = torch.add_(_5, (_0).forward(argument_1, ), alpha=1)
    return (_3).forward1(input, )
