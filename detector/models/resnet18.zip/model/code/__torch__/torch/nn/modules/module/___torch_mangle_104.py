op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  conv3X3 : __torch__.torch.nn.modules.module.___torch_mangle_89.Module
  conv5X5_1 : __torch__.torch.nn.modules.module.___torch_mangle_93.Module
  conv5X5_2 : __torch__.torch.nn.modules.module.___torch_mangle_96.Module
  conv7X7_2 : __torch__.torch.nn.modules.module.___torch_mangle_100.Module
  conv7x7_3 : __torch__.torch.nn.modules.module.___torch_mangle_103.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_104.Module,
    argument_1: Tensor) -> Tensor:
    _0 = self.conv7x7_3
    _1 = self.conv7X7_2
    _2 = self.conv5X5_2
    _3 = self.conv5X5_1
    _4 = (self.conv3X3).forward(argument_1, )
    _5 = (_3).forward(argument_1, )
    _6 = [_4, (_2).forward(_5, ), (_0).forward((_1).forward(_5, ), )]
    input = torch.cat(_6, 1)
    return torch.relu(input)
