op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  output1 : __torch__.torch.nn.modules.module.___torch_mangle_69.Module
  output2 : __torch__.torch.nn.modules.module.___torch_mangle_73.Module
  output3 : __torch__.torch.nn.modules.module.___torch_mangle_77.Module
  merge1 : __torch__.torch.nn.modules.module.___torch_mangle_81.Module
  merge2 : __torch__.torch.nn.modules.module.___torch_mangle_85.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_86.Module,
    argument_1: Tensor,
    argument_2: Tensor,
    argument_3: Tensor) -> Tuple[Tensor, Tensor, Tensor, Tensor, Tensor]:
    _0 = self.merge1
    _1 = self.merge2
    _2 = self.output3
    _3 = self.output2
    _4 = (self.output1).forward(argument_1, )
    _5 = (_3).forward(argument_2, )
    _6 = (_2).forward(argument_3, )
    _7 = ops.prim.NumToTensor(torch.size(_5, 2))
    _8 = ops.prim.NumToTensor(torch.size(_5, 3))
    up3 = torch.upsample_nearest2d(_6, [int(_7), int(_8)])
    input = torch.add(_5, up3, alpha=1)
    _9 = (_1).forward(input, )
    _10 = ops.prim.NumToTensor(torch.size(_4, 2))
    _11 = ops.prim.NumToTensor(torch.size(_4, 3))
    up2 = torch.upsample_nearest2d(_9, [int(_10), int(_11)])
    input0 = torch.add(_4, up2, alpha=1)
    _12 = ((_0).forward(input0, ), _9, _9, _6, _6)
    return _12
