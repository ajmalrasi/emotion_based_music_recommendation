op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  conv1 : __torch__.torch.nn.modules.module.___torch_mangle_26.Module
  bn1 : __torch__.torch.nn.modules.module.___torch_mangle_27.Module
  relu : __torch__.torch.nn.modules.module.___torch_mangle_28.Module
  conv2 : __torch__.torch.nn.modules.module.___torch_mangle_29.Module
  bn2 : __torch__.torch.nn.modules.module.___torch_mangle_30.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_31.Module,
    argument_1: Tensor) -> Tensor:
    _0 = self.bn2
    _1 = self.conv2
    _2 = self.relu
    _3 = (self.bn1).forward((self.conv1).forward(argument_1, ), )
    _4 = (_0).forward((_1).forward((_2).forward(_3, ), ), )
    input = torch.add_(_4, argument_1, alpha=1)
    return (_2).forward1(input, )
