op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  conv1 : __torch__.torch.nn.modules.module.Module
  bn1 : __torch__.torch.nn.modules.module.___torch_mangle_1.Module
  relu : __torch__.torch.nn.modules.module.___torch_mangle_2.Module
  maxpool : __torch__.torch.nn.modules.module.___torch_mangle_3.Module
  layer1 : __torch__.torch.nn.modules.module.___torch_mangle_16.Module
  layer2 : __torch__.torch.nn.modules.module.___torch_mangle_32.Module
  layer3 : __torch__.torch.nn.modules.module.___torch_mangle_48.Module
  layer4 : __torch__.torch.nn.modules.module.___torch_mangle_64.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_65.Module,
    input: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
    _0 = self.layer4
    _1 = self.layer3
    _2 = self.relu
    _3 = (self.bn1).forward((self.conv1).forward(input, ), )
    _4 = self.layer1
    _5 = (self.maxpool).forward((_2).forward(_3, ), )
    _6 = (self.layer2).forward((_4).forward(_5, ), )
    _7 = (_1).forward(_6, )
    return (_6, _7, (_0).forward(_7, ))
