op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  __annotations__["0"] = __torch__.torch.nn.modules.module.___torch_mangle_156.Module
  __annotations__["1"] = __torch__.torch.nn.modules.module.___torch_mangle_158.Module
  __annotations__["2"] = __torch__.torch.nn.modules.module.___torch_mangle_160.Module
