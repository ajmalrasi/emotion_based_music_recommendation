op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  __annotations__["0"] = __torch__.torch.nn.modules.module.___torch_mangle_142.Module
  __annotations__["1"] = __torch__.torch.nn.modules.module.___torch_mangle_144.Module
  __annotations__["2"] = __torch__.torch.nn.modules.module.___torch_mangle_146.Module
