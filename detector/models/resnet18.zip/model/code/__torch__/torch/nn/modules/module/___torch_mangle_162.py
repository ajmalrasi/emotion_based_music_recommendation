op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  body : __torch__.torch.nn.modules.module.___torch_mangle_65.Module
  fpn : __torch__.torch.nn.modules.module.___torch_mangle_86.Module
  ssh1 : __torch__.torch.nn.modules.module.___torch_mangle_104.Module
  ssh2 : __torch__.torch.nn.modules.module.___torch_mangle_122.Module
  ssh3 : __torch__.torch.nn.modules.module.___torch_mangle_140.Module
  ClassHead : __torch__.torch.nn.modules.module.___torch_mangle_147.Module
  BboxHead : __torch__.torch.nn.modules.module.___torch_mangle_154.Module
  LandmarkHead : __torch__.torch.nn.modules.module.___torch_mangle_161.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_162.Module,
    input: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
    _0 = getattr(self.LandmarkHead, "2")
    _1 = getattr(self.LandmarkHead, "1")
    _2 = getattr(self.LandmarkHead, "0")
    _3 = getattr(self.ClassHead, "2")
    _4 = getattr(self.ClassHead, "1")
    _5 = getattr(self.ClassHead, "0")
    _6 = getattr(self.BboxHead, "2")
    _7 = getattr(self.BboxHead, "1")
    _8 = getattr(self.BboxHead, "0")
    _9 = self.ssh3
    _10 = self.ssh2
    _11 = self.ssh1
    _12 = self.fpn
    _13, _14, _15, = (self.body).forward(input, )
    _16, _17, _18, _19, _20, = (_12).forward(_13, _14, _15, )
    _21 = (_11).forward(_16, )
    _22 = (_10).forward(_17, _18, )
    _23 = (_9).forward(_19, _20, )
    _24 = [(_8).forward(_21, ), (_7).forward(_22, ), (_6).forward(_23, )]
    _25 = torch.cat(_24, 1)
    _26 = [(_5).forward(_21, ), (_4).forward(_22, ), (_3).forward(_23, )]
    input0 = torch.cat(_26, 1)
    _27 = [(_2).forward(_21, ), (_1).forward(_22, ), (_0).forward(_23, )]
    _28 = torch.cat(_27, 1)
    _29 = (_25, torch.softmax(input0, -1, None), _28)
    return _29
