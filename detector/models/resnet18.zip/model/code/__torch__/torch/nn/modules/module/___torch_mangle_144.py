op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  conv1x1 : __torch__.torch.nn.modules.module.___torch_mangle_143.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_144.Module,
    argument_1: Tensor) -> Tensor:
    _0 = (self.conv1x1).forward(argument_1, )
    out = torch.contiguous(torch.permute(_0, [0, 2, 3, 1]), memory_format=0)
    _1 = ops.prim.NumToTensor(torch.size(out, 0))
    return torch.view(out, [int(_1), -1, 2])
