op_version_set = 1
class Module(Module):
  __parameters__ = []
  training : bool
  conv1 : __torch__.torch.nn.modules.module.___torch_mangle_17.Module
  bn1 : __torch__.torch.nn.modules.module.___torch_mangle_18.Module
  relu : __torch__.torch.nn.modules.module.___torch_mangle_19.Module
  conv2 : __torch__.torch.nn.modules.module.___torch_mangle_20.Module
  bn2 : __torch__.torch.nn.modules.module.___torch_mangle_21.Module
  downsample : __torch__.torch.nn.modules.module.___torch_mangle_24.Module
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_25.Module,
    argument_1: Tensor) -> Tensor:
    _0 = self.downsample
    _1 = self.bn2
    _2 = self.conv2
    _3 = self.relu
    _4 = (self.bn1).forward((self.conv1).forward(argument_1, ), )
    _5 = (_1).forward((_2).forward((_3).forward(_4, ), ), )
    input = torch.add_(_5, (_0).forward(argument_1, ), alpha=1)
    return (_3).forward1(input, )
