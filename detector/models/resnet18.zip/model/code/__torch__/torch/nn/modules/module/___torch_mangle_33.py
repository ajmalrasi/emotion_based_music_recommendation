op_version_set = 1
class Module(Module):
  __parameters__ = ["weight", ]
  training : bool
  weight : Tensor
  def forward(self: __torch__.torch.nn.modules.module.___torch_mangle_33.Module,
    argument_1: Tensor) -> Tensor:
    input = torch._convolution(argument_1, self.weight, None, [2, 2], [1, 1], [1, 1], False, [0, 0], 1, False, False, True)
    return input
